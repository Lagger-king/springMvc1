package com.iris.model;

public class Car {
	
	private int CarNo;
	private String Name;
	private Engine Eobj1;
	
	public void setCarNo(int carNo) {
		CarNo = carNo;
	}
	public void setName(String name) {
		Name = name;
	}
	public void setEobj1(Engine eobj1) {
		Eobj1 = eobj1;
	}
	
	public Car(int carNo, String name, Engine eobj1) {
		super();
		CarNo = carNo;
		Name = name;
		Eobj1 = eobj1;
	}

	@Override
	public String toString() {
		return "Car [CarNo=" + CarNo + ", Name=" + Name + ", Eobj1=" + Eobj1 + "]";
	}
	

}
